import streamlit as st
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# Load your dataset
@st.cache
def load_data():
    data = pd.read_csv('penguins.csv')
    return data

# Main app
def main():
    st.title('Penguin Species Dashboard')
    
    data = load_data()

    # Sidebar - Species selection
    species = st.sidebar.multiselect('Select Species:', options=data['species'].unique(), default=data['species'].unique())
    
    # Filtering data
    data_filtered = data[data['species'].isin(species)]
    
    # Displaying data count
    st.write(f"Displaying {len(data_filtered)} out of {len(data)} records")
    
    # Plot
    st.header('Penguin Physical Traits')
    fig, ax = plt.subplots()
    sns.scatterplot(data=data_filtered, x='flipper_length_mm', y='bill_length_mm', hue='species', style='island', ax=ax)
    plt.xlabel('Flipper Length (mm)')
    plt.ylabel('Bill Length (mm)')
    st.pyplot(fig)

if __name__ == "__main__":
    main()